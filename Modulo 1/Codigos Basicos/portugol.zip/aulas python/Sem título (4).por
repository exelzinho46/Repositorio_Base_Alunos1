programa {
  funcao inicio() {
   cadeia nome
   real nota1, nota2,nota3,media

   escreva("digite o nome do aluno: ") 
   leia(nome)

   escreva("Digite o valor da primeira nota: ")
   leia(nota1)

   escreva("Digite o valor da segunda nota: ")
   leia(nota2)

   escreva("digite o valor da terceira nota: ")
   leia(nota3)

   media = (nota1 + nota2 + nota3) / 3

   escreva("A media das notas de ",nome," foi: ",media)
   
  
















  }
}
