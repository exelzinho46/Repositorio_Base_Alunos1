programa {
  funcao inicio() {
   real peso,altura,imc

   escreva("Digite o peso e kg: ") 
   leia(peso)

   escreva("Digite a altura em m: ")
   leia(altura)

   imc = peso / (altura * altura)


   escreva("ro resultado é: ", imc)
   




  

  }
}
