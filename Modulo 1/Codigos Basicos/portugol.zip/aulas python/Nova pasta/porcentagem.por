programa {
  funcao inicio() {
    real valor_total,porcentagem,valor_parte,valor_com_desconto
    
    

    escreva("Digite o valor total: ")
    leia(valor_total)

    escreva("Qual é o valor da porcentagem: ")
    leia(porcentagem)

    
    valor_parte = valor_total * (porcentagem/100)

    escreva(porcentagem,"% de ",valor_total," = ",valor_parte)



























  }



}
