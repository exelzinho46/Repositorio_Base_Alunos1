programa {
  funcao inicio() {
    

    inteiro numero
    logico ehpositivo,ehnegativo,ehzero



    escreva("digite um numero: ")
    leia(numero)


    ehpositivo = numero > 0

    escreva("esse número é positivo: ",ehpositivo)

    ehnegativo = numero < 0

    escreva("\nesse número é negativo?  ",ehnegativo)
     ehzero = numero == 0

     escreva("\nesse numero é zero? ",ehzero)
     





  }

}
