programa {
  funcao inicio() {
   inteiro a,b


    escreva("Digite um valor para A: ")
    leia(a)


    escreva("Digite um valor para B: ")
    leia(b)


    escreva("COMPARAÇÕES: \n")
    escreva("a > b = ", a > b, "\n")
    escreva("a < b = ", a < b, "\n")
    escreva("a != b = ", a != b, "\n")
    escreva("a == b = ", a == b, "\n") 
  }
}
