programa {
  funcao inicio() {
   inteiro a, b ,c 
  escreva("digite o valor para variavel A: ")
   leia(a)
  escreva("digite o valor da variel b: ")
    leia(b)
  escreva("digite o valor da variavel c:")
     leia(c)


     escreva("COMPARAÇÕES:\N")
     escreva("(a > b) e (c == b) =", (a > b e c == b) , "\n")
     escreva(" (a < b) ou ( c > b)= ", (a < b ou c > b), "\n")
     escreva("NAO (a != b)= ", nao ( a != b), "\n")


  }
}
