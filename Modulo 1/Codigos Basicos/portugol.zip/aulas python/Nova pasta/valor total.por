programa {
  funcao inicio() {
     real valor_total,porcentagem,valor_parte

     escreva("Digite o valor total: ")
     leia(valor_total)

     
     escreva("Digite o valor da porcentagem: ")
     leia(porcentagem)

     valor_total * (porcentagem/100) + valor_parte

     valor_parte = valor_total * (porcentagem/100)

     escreva("o resultado é: ", valor_parte)
     


      


      



     
  }
}
