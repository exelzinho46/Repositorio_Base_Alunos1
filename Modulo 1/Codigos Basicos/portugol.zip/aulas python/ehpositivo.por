programa {
  funcao inicio() {
    

    inteiro numero
    logico ehpositivo

    escreva("digite um numero: ")
    leia(numero)


    ehpositivo = numero > 0
    escreva("esse número é positivo: ",ehpositivo)

    
  }

}
