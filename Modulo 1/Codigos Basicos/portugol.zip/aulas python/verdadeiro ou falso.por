programa {
  funcao inicio() {
    inteiro numero
    logico ehpositivo

    escreva("Digite um numero ")
    leia(numero)


    ehpositivo = numero < 0
    escreva("esse numero é falso positivo? ", ehpositivo)
    
  }
}
