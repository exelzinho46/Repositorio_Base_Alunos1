programa {
  funcao inicio() {
    //escreva() -> mostra texto na tela
    //leia() -> pega valores digitados no teclado

    // texto texto texto nao é execultado




  }
}
