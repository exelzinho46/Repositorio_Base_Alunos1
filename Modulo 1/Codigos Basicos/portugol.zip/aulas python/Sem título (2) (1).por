programa {
  funcao inicio() {
    inteiro numero1
    inteiro numero2
    inteiro resultado

    escreva("Digite o primeiro número:")
    leia(numero1)
    
    escreva("Digite o segundo número:")
    leia(numero1)

    resultado = numero1  numero2
    
    escreva("o resultado da soma é: ", resultado)

    

  }
}